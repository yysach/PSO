import networkx as nx
from os import listdir
from subprocess import call, Popen, PIPE
from paramiko import Transport
from time import sleep
import sys, json
from mininet.net import Mininet
from mininet.node import Controller, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel
from mininet.link import TCLink
from network_evaluation import avgPingTime, avgSpeedUsingPerf
from traffic_generator import create_traffic, set_thread_start
import geopy.distance

def distance_geopy(G, node1, node2):
	node1 = str(node1)
	node2 = str(node2)
	try : 
		lon = nx.get_node_attributes(G, 'Longitude')[node1]
		lat = nx.get_node_attributes(G, 'Latitude')[node1]

		coord_1 = (lat, lon)

		lon = nx.get_node_attributes(G, 'Longitude')[node2]
		lat = nx.get_node_attributes(G, 'Latitude')[node2]
		coord_2 = (lat, lon)

		return geopy.distance.distance(coord_1, coord_2).kilometers
	except:
		print ("distance calculation error",node1,node2)

def round_X(node_count, X):
	for switch, controller in X.items():
		X[switch] = int(controller)
		
	return X

def Read(graph_url):
	G = nx.read_graphml(graph_url)
	G = Remove_Single_Node(G)   #remove the single nodes in a graph.
	
	try :

		for n, nbrs in G.adjacency_iter():
			for nbr, eattr in nbrs.items():
				eattr['weight'] = distance_geopy(G, n, nbr)
				print eattr['weight']
		return G
	except Exception as e:
		return graph_url, e


#topo_list = []
#it decides no. of threads to be run as traffic, ex. 50%
LOAD_LIST = [100, 95, 50, 20, 10]


#no. of switches to run
UPPER_LIMIT = 100
LOWER_LIMIT = 0



def clear_mininet():
	call(["sudo", "mn", "-c"])
	call(["sudo", "mn", "-c"])



def wipeout_all(n_ctrl):
	for i in range(2, n_ctrl+2):
			wipeout('172.17.0.' + str(i))


#create a topology on mininet
def start_mininet(graph, n_ctrl, topo, case, algo, load_data):

	#Initialisation
	setLogLevel('info')
	net = Mininet() ############################Problem here ###########

	# controllers list
	odl_ctl_list = []

	# switches list
	odl_swt_list = []

	# host_list
	odl_host_list = []
	link = []
	simple_map = {}


	s = dict()
	h = dict()
	nodes = list()
	load_nodes = list()
	
	
	# get algo output
	data = json.load(open('algo_testing/comparison/' + topo[0:-8] + '.json', 'r'))
	placement_data = data['Case - '+str(case)]['algos'][algo]['placement']
	ctl_list = set(placement_data.values())
	ctl_list = [str(i) for i in ctl_list]
	n_ctrl = len(ctl_list)

	# Creating and adding controllers
	i=1
	for c in ctl_list:

		# add a remote controller using IP address and port
		controller = net.addController('c%s'%(c), controller=RemoteController,ip="172.17.0." + str(i+1), port=6653)
		i = i + 1
		odl_ctl_list.append(controller)
		simple_map['c%s'%(c)] =controller


	# add switches
	for node in graph.nodes():
		h[node] = net.addHost('h' + str(node))
		nodes.append(h[node])
		s[node] = net.addSwitch('s' + str(node))
		net.addLink(h[node], s[node])
		simple_map['s%s'%(str(node))] = s[node]

		# add load hosts
		load = load_data[str(node)]
		for i in range(0,load):
			host = net.addHost('l' + str(len(load_nodes)))
			net.addLink(host, s[node])
			load_nodes.append(host)



	G = graph
	G = Remove_Single_Node(G)   #remove the single nodes in a graph.
	
	#### Considered distance
	for e in graph.edges():
		

		link1 = net.addLink(s[e[0]], s[e[1]], cls=TCLink)
		
		# add delay on one of the link's interface
		try:
			#delay = distance/(speed of light)

			delay = G[e[0]][e[1]]['weight']/300.0
			link1.intf1.config( delay=str(delay)+'ms' )
		except Exception as e:
			print(e)

	net.build()

	for controller in odl_ctl_list:
		controller.start()


	for key,value in placement_data.items():
		controllers = []
		controllers.append(simple_map['c%s'%(str(value))])
		switch = simple_map['s%s'%(key)]

		# if you want onos to decide the distribution
		# change 'controllers' with 'odl_ctl_list'

		switch.start(controllers)
		#switch.start(odl_ctl_list)
			
	net.start()
	net.staticArp()
	#CLI(net)
	return net, h, nodes, load_nodes


def Remove_Single_Node(graph):
	for node in graph.nodes():
		if nx.is_isolate(graph,node):
			graph.remove_node(node)
	return graph




# code to ssh into controllers and wipe out automatically
def wipeout(hostname):
	nbytes = 4096
	port = 8101
	username = 'karaf' 
	password = 'karaf'
	command = 'wipe-out please'

	client = Transport((hostname, port))
	client.connect(username=username, password=password)
	stdout_data = []
	stderr_data = []
	session = client.open_channel(kind='session')
	session.exec_command(command)

	while True:
	    if session.recv_ready():
		stdout_data.append(session.recv(nbytes))
	    if session.recv_stderr_ready():
		stderr_data.append(session.recv_stderr(nbytes))
	    if session.exit_status_ready():
		break

	print ''.join(stdout_data)
	print ''.join(stderr_data)
	session.close()
	client.close()


def process_topo_nctrl(topo, graph, n_ctrl, case, algo):
	try:
		#Wiping out all controllers to be used 
		wipeout_all(n_ctrl)

		#Creating topology in mininet
		

		#Loading existing solution file (or creating new)
		try:	
			topo_data = json.load(open('algo_testing/comparison/' + topo[0:-8] + '.json', 'r'))
			algo_data = topo_data['Case - '+str(case)]['algos'][algo]
			load_data = topo_data['Case - '+str(case)]['load(l)']

			# start mininet
			net, h, nodes, load_nodes = start_mininet(graph, n_ctrl, topo, case, algo, load_data)
			
			# wait until hosts are booting up
			sleep(8*len(nodes))
			print (algo_data['placement'])


			# send start traffic tread signal
			set_thread_start(True)


			# start threads
			create_traffic(net, h, graph, 50, nodes)

			sleep(15)

			# latency_onos = placement given
			# latency_onos(cpp of onos) = placement decided by onos

			algo_data['latency_onos'] = avgPingTime(net, nodes, 50)
			#algo_data['latency_onos(cpp of onos)'] = avgPingTime(net, nodes, 50)
			


			topo_data['Case - '+str(case)]['algos'][algo] = algo_data
			#topo_data[n_ctrl]['traffic'][load]['bw'] = avgSpeedUsingPerf(net, h, graph, load)

			# stop threads
			set_thread_start(False)
			sleep(4)

			#Storing dictionary in solution file
			json.dump(topo_data, open('algo_testing/comparison/' + topo[0:-8] + '.json', 'w+'), indent=4, sort_keys=True)	
			sleep(200)
			clear_mininet()
		except Exception as e:
			print e

	except Exception as e:
		clear_mininet()
		wipeout_all(n_ctrl)
		print('process_topo_ctrl::', e)		
		pass
	

def create_cluster( topo, case, algo): ################problem here#################
	try :
		data = json.load(open('algo_testing/comparison/' + topo[0:-8] + '.json', 'r'))
		case_data = data['Case - '+str(case)]
		switch2controller = case_data['algos'][algo]['placement']  ####problem here###

		controllers = set(switch2controller.values())
		n_ctrl = len(controllers)
		if n_ctrl<16:
			#Forming Cluster
	
			cluster_cmd = './onos-form-cluster -u karaf -p karaf '
			for i in range(2, n_ctrl+2):
				cluster_cmd  = cluster_cmd + '172.17.0.' + str(i) + ' '
			print(Popen(['/bin/sh', '-c', cluster_cmd], stdout=PIPE).communicate()[0])
		else:
			print ('Too many controllers')

		sleep(200)
		return n_ctrl
	except Exception as e:
		print ('create_cluster ::',e)
		return 0
		
def get_ctrl_count(topo, case, algo):
	data = json.load(open('algo_testing/comparison/' + topo[0:-8] + '.json', 'r'))
	case_data = data['Case - '+str(case)]
	switch2controller = case_data['algos'][algo]['placement']

	controllers = set(switch2controller.values())
	n_ctrl = len(controllers)
	return n_ctrl


def start_code():
	#Running every topology for that many controllers

	# topo_list = list of topologies where you wanna run 
	# case_list = list of scenerios where you wanna run for these topologies
	# alg_list = list of algorithms
    #topo_list = ['Savvis.graphml','Agis.graphml',]        
	topo_list = ['Savvis.graphml',]
	case_list = [4,5,6,7,8,9]
	#case_list = [1,2,3,4,5,6,7,8,9,10,11,12]
	#algo_list = ['vbo','pso','tlbo','jaya']
	algo_list = ['change_in_vbo',]
	for topo in topo_list:
		try:
			for case in case_list:
				for algo in algo_list:
					
					n_ctrl = get_ctrl_count(topo, case, algo)
					print (topo, case, algo, n_ctrl)
					if n_ctrl < 10:
						clear_mininet()
						print (topo, case, algo, n_ctrl)
						cmd = 'sudo sh start_controllers.sh ' + str(n_ctrl)
						print(Popen(['/bin/sh', '-c', cmd]).communicate()[0])
						
						n_ctrl = create_cluster(topo, case, algo)
						graph = Read('algo_testing/archive/' + topo)
						graph = Remove_Single_Node(graph)
						n_nodes = graph.number_of_nodes() 
						if nx.number_connected_components(graph) > 1:
							continue
						if n_nodes >= LOWER_LIMIT and n_nodes <= UPPER_LIMIT:	
							process_topo_nctrl(topo, graph, n_ctrl, case, algo)
		except Exception as e:
			clear_mininet()
			wipeout_all(15)
			print('start_code::', e)
			continue

if __name__ == '__main__':



	start_code()


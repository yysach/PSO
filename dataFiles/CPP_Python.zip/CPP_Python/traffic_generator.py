#Generating random traffic in network

from threading import Thread
from random import randint

ports = dict()
thread_start = True

#Function for a thread
def iperf_thread(net, nodes, G, load_nodes):
	try:
		l = len(load_nodes)
		while thread_start:	
			i = randint(0, l)
			j = randint(0, l)
			if i==j:
				continue
			sec = 2
			while True:	
				print('searching......')
				port = random.randint(10000, 50000)
				if port not in ports or ports[port] == 0:
					break
			ports[port] = 1
			net.iperf(hosts=[load_nodes[i], load_nodes[j]], seconds=sec, port=port)
			ports[port] = 0
	except:
		pass


#Function to create all threads
def create_traffic(net, nodes, G, percentage, load_nodes):
	global ports
	ports = dict()
	n_threads = (percentage * G.number_of_nodes())
	print('load: ', percentage, ' threads: ', n_threads)
	try:
		for i in range(0, n_threads): 
			t = Thread(target=iperf_thread, args=(net, nodes, G, load_nodes))
			t.setDaemon(True);
			t.start()
	except Exception as e:
		print('create_traffic::', e)
		pass


#Function to start or stop all threads
def set_thread_start(val):
	global thread_start
	thread_start = val


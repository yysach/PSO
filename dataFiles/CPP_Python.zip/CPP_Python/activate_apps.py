#Activate apps in all controllers using ssh connection

from paramiko import Transport
from time import sleep
from sys import argv


nbytes = 4096
port = 8101
username = 'karaf' 
password = 'karaf'
cmd = list()
cmd.append('app activate org.onosproject.openflow')
cmd.append('app activate org.onosproject.fwd')
client = None

for i in range(2, int(argv[1])+2):
	hostname = "172.17.0." + str(i)
	for c in cmd:
		while True:
			try:
				print("Trying to connect...")
				client = Transport((hostname, port))
				client.connect(username=username, password=password)
				break
			except:
				sleep(10)

		stdout_data = []
		stderr_data = []
		session = client.open_channel(kind='session')
		session.exec_command(c)

		while True:
		    if session.recv_ready():
			stdout_data.append(session.recv(nbytes))
		    if session.recv_stderr_ready():
			stderr_data.append(session.recv_stderr(nbytes))
		    if session.exit_status_ready():
			break

		print ''.join(stdout_data)
		print ''.join(stderr_data)

		session.close()
		client.close()

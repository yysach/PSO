import networkx as nx
from random import *
from latency import calculate_latency, calculate_actual_avg_latency
from tlbo import initialize_particles, get_random_dict, find_x_best, safe_check
from jaya import find_x_worst

def sort_by_latency(items, sort_by):
	sort_by, items = (list(t) for t in zip(*sorted(zip(sort_by, items))))
	return items, sort_by 


def vbo(G, N, itmax, L, l):
	alpha = 0.1
	n_alpha = alpha * N

	shortest_path_length = dict()

	particles =initialize_particles(G, N)
	latencies = calculate_latency(G, particles, shortest_path_length, L, l)
	node_count = nx.number_of_nodes(G)

	for itr in range(0, itmax):

		particles, latencies = sort_by_latency(particles, latencies)

		X_best, best_latency = find_x_best(particles, latencies)
		
		X_worst, worst_latency = find_x_worst(particles, latencies)

		print 'vbo - ', itr, best_latency
		

		c1 = 1.50
		c2 = 1.25

		new_particles = particles
		for i in range(0, int(n_alpha)):
			rA = get_random_dict(node_count)
			for key, value in particles[i].items():
				new_particles[i][key] = value + rA[key] * (X_best[key] -  X_worst[key])
				new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

		
		for i in range(int(n_alpha), N):
			X_peer = randint(0, N-1)
			while N>1 and (i == X_peer):
				X_peer = randint(0, N-1)

			rB = get_random_dict(node_count)

			if latencies[i] < latencies[X_peer]:
				for key, value in particles[i].items():
					new_particles[i][key] = value + c1 * rB[key] * (X_best[key] - particles[X_peer][key])
					new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

			elif latencies[i] > latencies[X_peer]:
				for key, value in particles[i].items():
					new_particles[i][key] = value + c2 * rB[key]*(particles[X_peer][key] - value)
					new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

			else :
				for key, value in particles[i].items():
					new_particles[i][key] = 2 * rB[key] * value
					new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)


		new_latencies = calculate_latency(G, new_particles, shortest_path_length, L, l)

		for i in range(0, N):
			if new_latencies[i] < latencies[i]:
				latencies[i] = new_latencies[i]
				particles[i] = new_particles[i]

	opt_placement, opt_latency = find_x_best(particles, latencies)

	return opt_placement, calculate_actual_avg_latency(G, opt_placement, shortest_path_length, L, l)
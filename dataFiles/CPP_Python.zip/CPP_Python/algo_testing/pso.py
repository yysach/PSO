import networkx as nx
from random import *
from latency import calculate_latency, calculate_actual_avg_latency

def initialize_particles(G, N):
	particles = list()
	velocities = list()
	node_count = nx.number_of_nodes(G)
	for i in range(0, N):
		X = dict()
		V = dict()
		for j in range(0, node_count):
			x = randint(0, node_count-1)
			v = random()
			X[j] = x
			V[j] = v
		particles.append(X)
		velocities.append(V)

	return particles, velocities

def find_gbest(particles, latencies):
	gbest = particles[0]
	gbest_latency = latencies[0]
	for i in range(0, len(particles)):
		if latencies[i] < gbest_latency:
			gbest = particles[i]
			gbest_latency = latencies[i]
	return gbest, gbest_latency

def safe_add(x, v, node_count):
	if ( ((x+v) <= node_count-1 + 0.49) and ((x+v)>= 0)):
		return x+v
	else :
		return randint(0, node_count-1)




def pso(G, N, itmax, L, l):
	#d = no_of_controllers
	#N = no_of_particles
	#itmax = no_of_ierations
	#particles = [X0, X1, ..., Xn-1]
	#X = [c0, c1, ..., cd-1]
	#velocities = [V0, V1, .....Vn-1]
	#V = [v0, v1, ..., vd-1]
	#pbest = [pbest0, pbest1, ..., pbestn-1]
	#pbest0 = [c0, c1, ..., cd-1]
	#gbest = [c0, c1, ..., cd-1]
	
	#control_parameters
	w_intial = 0.9 
	w_final = 0.1
	c1 = 0.2
	c2 = 0.2
	shortest_path_length = dict()

	particles, velocities = initialize_particles(G, N)
	pbest = particles
	latencies = calculate_latency(G, particles, shortest_path_length, L, l)
	pbest_latencies = latencies

	gbest, gbest_latency = find_gbest(particles, latencies)
	node_count = nx.number_of_nodes(G)
	print 'pso - ', node_count

	for itr in range(0, itmax):
		w = w_intial + 1.0 * ( w_final - w_intial ) * itr/itmax
		for i in range(0, N):
			velocity = velocities[i]
			for key, value in velocity.items():
				r1 = random()
				r2 = random()
				v = w * value + 1.0 * c1 * r1 * (pbest[i][key] - particles[i][key]) + 1.0 * c2 * r2 * (gbest[key] - particles[i][key])
				velocities[i][key] = v

				particles[i][key] = safe_add(v, particles[i][key], node_count)

		latencies = calculate_latency(G, particles, shortest_path_length, L, l)

		
		for i in range(0, N):
			if latencies[i] < pbest_latencies[i]:
				pbest[i] = particles[i]
				pbest_latencies[i] = latencies[i]

				if latencies[i] < gbest_latency:
					gbest = particles[i]
					gbest_latency = latencies[i]
		print 'pso - ', itr, gbest_latency
	return gbest, calculate_actual_avg_latency(G, gbest, shortest_path_length, L, l)

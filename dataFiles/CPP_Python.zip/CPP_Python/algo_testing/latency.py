import geopy.distance
import networkx as nx
from random import *


def distance_geopy(G, node1, node2):
	node1 = str(node1)
	node2 = str(node2)
	try : 
		lon = nx.get_node_attributes(G, 'Longitude')[node1]
		lat = nx.get_node_attributes(G, 'Latitude')[node1]

		coord_1 = (lat, lon)

		lon = nx.get_node_attributes(G, 'Longitude')[node2]
		lat = nx.get_node_attributes(G, 'Latitude')[node2]
		coord_2 = (lat, lon)

		return geopy.distance.distance(coord_1, coord_2).kilometers
	except:
		print ("distance calculation error",node1,node2)

def round_X(node_count, X):
	for switch, controller in X.items():
		X[switch] = int(controller)
		
	return X

def calculate_S2Clatency(G, X, shortest_path_length):
	S2Clatency = 0
	try:
		for switch, controller in X.items():
			if shortest_path_length.has_key(switch):
				if shortest_path_length[switch].has_key(controller):
					dis = shortest_path_length[switch][controller]
				else:
					dis = nx.shortest_path_length(G, str(switch), str(controller), weight='weight')
			else:
				shortest_path_length[switch] = dict()
				dis = nx.shortest_path_length(G, str(switch), str(controller), weight='weight')
			shortest_path_length[switch][controller] = dis

			S2Clatency = S2Clatency + dis

			avgS2Clatency =1.0 * S2Clatency / nx.number_of_nodes(G)

		return S2Clatency, avgS2Clatency
	except Exception as e:
		print e

def calculate_C2Clatency(G, X, shortest_path_length):
	controllerList = set(X.values())
	k = len(controllerList)
	C2Clatency = 0
	avgC2Clatency = 0
	try:
		for node1 in controllerList:
			for node2 in controllerList:
				if int(node1)>int(node2):
					#choose nc2
					if shortest_path_length.has_key(node1):
						if shortest_path_length[node1].has_key(node2):
							dis = shortest_path_length[node1][node2]
						else:
							dis = nx.shortest_path_length(G, str(node1), str(node2), weight='weight')
					else:
						shortest_path_length[node1] = dict()
						dis = nx.shortest_path_length(G, str(node1), str(node2), weight='weight')
					shortest_path_length[node1][node2] = dis
					C2Clatency = C2Clatency + dis

		if C2Clatency > 0 and k > 1:
			avgC2Clatency = 1.0 * C2Clatency / (k*(k-1)/2)

		return C2Clatency, avgC2Clatency
	except Exception as e:
		print e 

def switches(X, controller):
	S = []
	for key, value in X.items():
		if value == controller:
			S.append(key)
	return S

def load_of_switches(l, S):
	sum_of_load = 0
	for switch in S:
		sum_of_load = sum_of_load + l[str(switch)]
	return sum_of_load


def calculate_penalty(G, X, l, L, node_count):
	try:
		controllerList = set(X.values())
		k = len(list(controllerList))
		penalty = 0

		for controller in controllerList:
			S = switches(X, controller)
			totalLoad = load_of_switches(l, S)
			#print controller, totalLoad , L[str(controller)]
			penalty = penalty + (max(0, (totalLoad - L[str(controller)])))**2
		return (1+penalty) + (k**3) 
	except Exception as e:
		pass

def unit_load_gen(X, capacity):
	l = dict()
	L = dict()
	for key, value in X.items():
		l[key] = 1
		L[key] = capacity

	return l, L

def calculate_avg_latency(G, X, shortest_path_length, L, l):
	try:
		node_count = nx.number_of_nodes(G)
		X = round_X(node_count, X)
		S2Clatency, avgS2Clatency = calculate_S2Clatency(G, X, shortest_path_length)
		C2Clatency, avgC2Clatency = calculate_C2Clatency(G, X, shortest_path_length)

		penalty = calculate_penalty(G, X, l, L, node_count)
		avg_latency = (S2Clatency + C2Clatency) * penalty
		return avg_latency
	except Exception as e:
		pass

def calculate_actual_avg_latency(G, X, shortest_path_length, L , l):
	node_count = nx.number_of_nodes(G)
	X = round_X(node_count, X)
	S2Clatency, avgS2Clatency = calculate_S2Clatency(G, X, shortest_path_length)
	C2Clatency, avgC2Clatency = calculate_C2Clatency(G, X, shortest_path_length)

	penalty = calculate_penalty(G, X, l, L, node_count)
	avg_latency = (avgS2Clatency + avgC2Clatency)
	return avg_latency

def calculate_latency(G, particles, shortest_path_length, L, l):
	try:
		latencies = list()
		for X in particles:
			latency = calculate_avg_latency(G, X, shortest_path_length, L, l)
			latencies.append(latency)
		return latencies
	except Exception as e:
		print e
import networkx as nx
from random import *
from latency import calculate_latency, calculate_actual_avg_latency
from tlbo import initialize_particles, get_random_dict, find_x_best, safe_check

def find_x_worst(particles, latencies):
	gbest = particles[0]
	gbest_latency = latencies[0]
	for i in range(0, len(particles)):
		if latencies[i] > gbest_latency:
			gbest = particles[i]
			gbest_latency = latencies[i]
	return gbest, gbest_latency


def jaya(G, N, itmax, L, l):

	shortest_path_length = dict()
	particles =initialize_particles(G, N)
	latencies = calculate_latency(G, particles, shortest_path_length, L, l)
	node_count = nx.number_of_nodes(G)
	hello = 0.2
	for itr in range(0, itmax):


		X_worst, worst_latency = find_x_worst(particles, latencies)
		X_best, best_latency = find_x_best(particles, latencies)
		print 'jaya -',itr, best_latency, worst_latency

		r1 = get_random_dict(node_count)
		r2 = get_random_dict(node_count)

		new_particles = particles
		for i in range(0, N):

			for key, value in particles[i].items():
				if random() < hello :
					new_particles[i][key] = value + r1[key] * (X_best[key] - value) - r2[key]*(X_worst[key] - value)
					new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

		new_latencies = calculate_latency(G, new_particles, shortest_path_length, L, l)

		for i in range(0, N):
			if new_latencies[i] < latencies[i]:
				latencies[i] = new_latencies[i]
				particles[i] = new_particles[i]

	opt_placement, opt_latency = find_x_best(particles, latencies)

	return opt_placement, calculate_actual_avg_latency(G, opt_placement, shortest_path_length, L, l)
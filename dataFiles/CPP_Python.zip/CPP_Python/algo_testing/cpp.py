import networkx as nx
#import matplotlib.pyplot as plt
import time
import math
import operator
import json
from tlbo import tlbo
from jaya import jaya
from pso import pso
from vbo import vbo
from change_in_vbo import change_in_vbo
from latency import distance_geopy
import glob
from random import *


#remove the single nodes in a graph.
def Remove_Single_Node(graph):
	for node in graph.nodes():
		if nx.is_isolate(graph,node):
			graph.remove_node(node)
	return graph


#given a graph location to read the graph, graphml style only.
def Read(graph_url):
	G = nx.read_graphml(graph_url)
	G = Remove_Single_Node(G)   #remove the single nodes in a graph.
	
	try :
		for node in G.nodes():
			lon = nx.get_node_attributes(G, 'Longitude')[node]
			lat = nx.get_node_attributes(G, 'Latitude')[node]
			#print node, lat, lon

		for n, nbrs in G.adjacency_iter():
			for nbr, eattr in nbrs.items():
				eattr['weight'] = distance_geopy(G, n, nbr)
				#print eattr['weight']
		return G
	except Exception as e:
		return graph_url, e

def get_files(min_switches = 0, max_switch = 0):
	all_files = glob.glob('archive/*.graphml')
	count = 0
	good_files = list()
	for f in all_files:
		try :
			G = Read(f)
			if G != 0:	
				#placement, latency = change_in_vbo(G, 3, 1)
				if (nx.number_of_nodes(G) > 0):
					if (nx.number_of_nodes(G) < 100):
						if (nx.number_connected_components(G) < 2):
							count += 1
							good_files.append(f)
							print "hello", f, nx.number_of_nodes(G)
			else:
				pass
		except:
			pass
	return good_files

def calculate_std_dev(iterated_output, iterations):
	try:
		if iterations < 2:
			return 0

		avg_x = iterated_output['latency_theory_avg']
		x = 0

		for i in range(1, iterations+1):
			x += (iterated_output['iteration '+str(i)]['latency_theory'] - avg_x)**2
		
		x = x/(iterations-1)
		return math.sqrt(x)

	except Exception as e:
		print ("calculate_std_dev", e)

def call_algorithms(G, N, itmax, L, l, iterations):
	algos_json = dict()

	#change_in_vbo
	iterated_output = dict()
	sum_of_latency = 0
	latency_theory_min = 200000000
	latency_theory_min_loc = -1
	latency_theory_max = 0
	try:
		for i in range(1,iterations+1):

			algo_output = dict()
			algo_output['placement'], algo_output['latency_theory'] = change_in_vbo(G, N, itmax, L, l)
			algo_output['controllers'] = len(list(set(algo_output['placement'].values())))
			
			iterated_output['iteration '+str(i)] = algo_output
			sum_of_latency += algo_output['latency_theory']

			if (latency_theory_max < algo_output['latency_theory']):
				latency_theory_max = algo_output['latency_theory'] 

			if (latency_theory_min > algo_output['latency_theory']):
				latency_theory_min = algo_output['latency_theory']
				latency_theory_min_loc = i


		iterated_output['latency_theory_avg'] = sum_of_latency/iterations
		iterated_output['latency_theory_min'] = latency_theory_min
		iterated_output['latency_theory_max'] = latency_theory_max
		iterated_output['placement'] = iterated_output['iteration '+str(latency_theory_min_loc)]['placement']
		iterated_output['latency_theory_std_dev'] = calculate_std_dev(iterated_output, iterations)
		algos_json['change_in_vbo'] = iterated_output
	except Exception as e:
		print "error",e
		 


	#vbo
	iterated_output = dict()
	sum_of_latency = 0
	latency_theory_min = 200000000
	latency_theory_min_loc = -1
	latency_theory_max = 0
	for i in range(1,iterations+1):

		algo_output = dict()
		algo_output['placement'], algo_output['latency_theory'] = vbo(G, N, itmax , L, l)
		algo_output['controllers'] = len(list(set(algo_output['placement'].values())))
		iterated_output['iteration '+str(i)] = algo_output
		sum_of_latency += algo_output['latency_theory']

		if (latency_theory_max < algo_output['latency_theory']):
			latency_theory_max = algo_output['latency_theory'] 

		if (latency_theory_min > algo_output['latency_theory']):
			latency_theory_min = algo_output['latency_theory']
			latency_theory_min_loc = i


	iterated_output['latency_theory_avg'] = sum_of_latency/iterations
	iterated_output['latency_theory_min'] = latency_theory_min
	iterated_output['latency_theory_max'] = latency_theory_max
	iterated_output['placement'] = iterated_output['iteration '+str(latency_theory_min_loc)]['placement']
	iterated_output['latency_theory_std_dev'] = calculate_std_dev(iterated_output, iterations)
	algos_json['vbo'] = iterated_output

	#jaya
	iterated_output = dict()
	sum_of_latency = 0
	latency_theory_min = 200000000
	latency_theory_min_loc = -1
	latency_theory_max = 0
	for i in range(1,iterations+1):

		algo_output = dict()
		algo_output['placement'], algo_output['latency_theory'] = jaya(G, N, itmax, L, l)
		algo_output['controllers'] = len(list(set(algo_output['placement'].values())))
		iterated_output['iteration '+str(i)] = algo_output
		sum_of_latency += algo_output['latency_theory']

		if (latency_theory_max < algo_output['latency_theory']):
			latency_theory_max = algo_output['latency_theory'] 

		if (latency_theory_min > algo_output['latency_theory']):
			latency_theory_min = algo_output['latency_theory']
			latency_theory_min_loc = i


	iterated_output['latency_theory_avg'] = sum_of_latency/iterations
	iterated_output['latency_theory_min'] = latency_theory_min
	iterated_output['latency_theory_max'] = latency_theory_max
	iterated_output['placement'] = iterated_output['iteration '+str(latency_theory_min_loc)]['placement']
	iterated_output['latency_theory_std_dev'] = calculate_std_dev(iterated_output, iterations)
	algos_json['jaya'] = iterated_output

	# #tlbo
	iterated_output = dict()
	sum_of_latency = 0
	latency_theory_min = 200000000
	latency_theory_min_loc = -1
	latency_theory_max = 0
	for i in range(1,iterations+1):

		algo_output = dict()
		algo_output['placement'], algo_output['latency_theory'] = tlbo(G, N, itmax, L, l)
		algo_output['controllers'] = len(list(set(algo_output['placement'].values())))
		iterated_output['iteration '+str(i)] = algo_output
		sum_of_latency += algo_output['latency_theory']

		if (latency_theory_max < algo_output['latency_theory']):
			latency_theory_max = algo_output['latency_theory'] 

		if (latency_theory_min > algo_output['latency_theory']):
			latency_theory_min = algo_output['latency_theory']
			latency_theory_min_loc = i


	iterated_output['latency_theory_avg'] = sum_of_latency/iterations
	iterated_output['latency_theory_min'] = latency_theory_min
	iterated_output['latency_theory_max'] = latency_theory_max
	iterated_output['placement'] = iterated_output['iteration '+str(latency_theory_min_loc)]['placement']
	iterated_output['latency_theory_std_dev'] = calculate_std_dev(iterated_output, iterations)
	algos_json['tlbo'] = iterated_output


	#pso
	iterated_output = dict()
	sum_of_latency = 0
	latency_theory_min = 200000000
	latency_theory_min_loc = -1
	latency_theory_max = 0
	for i in range(1,iterations+1):

		algo_output = dict()
		algo_output['placement'], algo_output['latency_theory'] = pso(G, N, itmax, L, l)
		algo_output['controllers'] = len(list(set(algo_output['placement'].values())))
		iterated_output['iteration '+str(i)] = algo_output
		sum_of_latency += algo_output['latency_theory']

		if (latency_theory_max < algo_output['latency_theory']):
			latency_theory_max = algo_output['latency_theory'] 

		if (latency_theory_min > algo_output['latency_theory']):
			latency_theory_min = algo_output['latency_theory']
			latency_theory_min_loc = i



	iterated_output['latency_theory_avg'] = sum_of_latency/iterations
	iterated_output['latency_theory_min'] = latency_theory_min
	iterated_output['latency_theory_max'] = latency_theory_max
	iterated_output['placement'] = iterated_output['iteration '+str(latency_theory_min_loc)]['placement']
	iterated_output['latency_theory_std_dev'] = calculate_std_dev(iterated_output, iterations)
	algos_json['pso'] = iterated_output

	return algos_json



def execute_by_case(G, run_by_case, file_name, testing, iterations):

	json_file_name = 'comparison' + file_name[7:-8] + '.json'

	try:
		output_json = json.load(open(json_file_name,'r+'))
	except:
		output_json = dict()


	node_count = nx.number_of_nodes(G)
	output_json['no. of switches'] = node_count

	same_load = 5
	same_capacity = randint(6*same_load, 8*same_load)

	case_json = dict()
	#set unit weight on edges
	if (run_by_case - 1) % 4 <= 1:
		case_json['weight'] = 'unit weight'
		for n, nbrs in G.adjacency_iter():
			for nbr, eattr in nbrs.items():
				eattr['weight'] = 1

	#set lat-long on edges			
	else:
		case_json['weight'] = 'lat-long weight'
		for n, nbrs in G.adjacency_iter():
			for nbr, eattr in nbrs.items():
				eattr['weight'] = distance_geopy(G, n, nbr)



	#set load on switches
	load_on_switch = dict()
	#same _load
	if (run_by_case - 1) % 2 == 0:
		case_json['load_type'] = 'same'
		for node in G.nodes():
			load_on_switch[node] = same_load

	#different load
	else:
		case_json['load_type'] = 'different'
		for node in G.nodes():
			load_on_switch[node] = randint(0, 11)

	case_json['load(l)'] = load_on_switch


	#set capacity 
	capacity = dict()


	#upcapacited
	if run_by_case <= 4:
		case_json['capacity-type'] = 'un-capacited'
		for node in G.nodes():
			capacity[node] = node_count + 1000000

	#same_capacity 
	elif run_by_case <=8:
		case_json['capacity-type'] = 'same-capacity'
		for node in G.nodes():
			capacity[node] = same_capacity

	#diff capacity
	else :
		case_json['capacity-type'] = 'diff capacity'
		for node in G.nodes():
			capacity[node] = randint(6*same_load, 8*same_load)


	case_json['capacity(L)'] = capacity


	print ''
	print '-------------------------------------------------------------'
	print run_by_case," - " ,case_json['weight'], case_json['load_type'], case_json['capacity-type']
	print '-------------------------------------------------------------'
	print ''

	print capacity
	print load_on_switch
	algos_json = call_algorithms(G, 2 + 500*testing, min(20*node_count, 1 + 330*testing + node_count*testing), capacity, load_on_switch, iterations)
	case_json['algos'] = algos_json


	output_json['Case - ' + str(run_by_case)] = case_json 
	file_name = 'comparison' + file_name[7:-8] + '.json'
	json.dump(output_json,open(file_name,'w+'), indent=4, sort_keys=True)

files = get_files(10,20)
for file in files:
	try:
		G = Read(file)
		print file
		for i in range(1, 13):
			iterations = 10
			execute_by_case(G, i, file, 1, iterations)
	except Exception as e:
		print e





# jaya(G, 5, 30)
# tlbo(G, 5, 20)
# vbo(G, 5, 20)i

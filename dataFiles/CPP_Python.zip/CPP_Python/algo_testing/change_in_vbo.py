import networkx as nx
from random import *
from latency import calculate_latency, calculate_actual_avg_latency
from tlbo import initialize_particles, get_random_dict, find_x_best, safe_check
from jaya import find_x_worst

def sort_by_latency(items, sort_by):
	sort_by, items = (list(t) for t in zip(*sorted(zip(sort_by, items))))
	return items, sort_by 

paths = dict()


def find_new_x(G, X1, X2, fraction_to_move):
	global paths
	if paths.has_key(X1):
		if paths[X1].has_key(str(X2)):
			path = paths[X1][X2]
		else:
			path = nx.shortest_path(G, str(X1), str(X2))
			paths[X1][X2] = path
	else:
		path = nx.shortest_path(G, str(X1), str(X2))
		paths[X1] = dict()
		paths[X1][X2] = path

	steps = int(1.0 * len(path)*fraction_to_move)
	try:
		return int(path[steps])
	except:
		return X1



def change_in_vbo(G, N, itmax, L, l):
	alpha = 0.10
	n_alpha = alpha * N

	global paths
	paths = dict()
	shortest_path_length = dict()
	particles =initialize_particles(G, N)
	latencies = calculate_latency(G, particles, shortest_path_length, L, l)
	print 'pass vbo'
	node_count = nx.number_of_nodes(G)

	for itr in range(0, itmax):

		particles, latencies = sort_by_latency(particles, latencies)

		X_best, best_latency = find_x_best(particles, latencies)
		
		X_worst, worst_latency = find_x_worst(particles, latencies)

		print 'change_in_vbo - ', itr, best_latency, worst_latency
		

		c1 = 0.50
		c2 = 0.25

		new_particles = particles
		for i in range(0, int(n_alpha)):
			rA = get_random_dict(node_count)
			hello = 0.20
			for key, value in particles[i].items():
				if random() < hello :
					new_particles[i][key] = find_new_x(G, value, X_best[key], rA[key])
				#new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

		
		for i in range(int(n_alpha), N):
			X_peer = randint(0, N-1)
			while N>1 and (i == X_peer):
				X_peer = randint(0, N-1)

			rB = get_random_dict(node_count)
			hello = 0.2
			if latencies[i] < latencies[X_peer]:
				for key, value in particles[i].items():
					if random() < hello + 0.4: 
						new_particles[i][key] = find_new_x(G, value, X_best[key], rB[key])
					#new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

			elif latencies[i] > latencies[X_peer]:
				for key, value in particles[i].items():
					if random() < hello + 0.2:
						new_particles[i][key] = find_new_x(G, value, particles[X_peer][key], min(1, 2 * rB[key]))
					#new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

			else :
				for key, value in particles[i].items():
					if random() < hello + 0.2 :
						new_particles[i][key] = find_new_x(G, value, X_best[key], min(1, 2 * rB[key]))
					#new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)


		new_latencies = calculate_latency(G, new_particles, shortest_path_length, L, l)

		for i in range(0, N):
			if new_latencies[i] < latencies[i]:
				latencies[i] = new_latencies[i]
				particles[i] = new_particles[i]

	opt_placement, opt_latency = find_x_best(particles, latencies)

	return opt_placement, calculate_actual_avg_latency(G, opt_placement, shortest_path_length, L, l)
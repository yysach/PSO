import networkx as nx
from random import *
from latency import calculate_latency , calculate_actual_avg_latency


def initialize_particles(G, N):
	particles = list()
	node_count = nx.number_of_nodes(G)
	for i in range(0, N):
		X = dict()
		for j in range(0, node_count):
			x = randint(0, node_count-1)
			X[j] = x
		particles.append(X)

	return particles

def get_random_dict(node_count):
	r = dict()
	for i in range(0, node_count):
		r[i] = random()/2
	return r

def calculate_particle_mean(particles, node_count):
	X_mean = dict()
	for X in particles:
		for key, value in X.items():
			if key in X_mean.keys():
				X_mean[key] += X[key]
			else :
				X_mean[key] = X[key]

	return X_mean

def find_x_best(particles, latencies):
	gbest = particles[0]
	gbest_latency = latencies[0]
	for i in range(0, len(particles)):
		if latencies[i] < gbest_latency:
			gbest = particles[i]
			gbest_latency = latencies[i]
	return gbest, gbest_latency

def safe_check(key, x, node_count):
	if x <= (node_count-1 + 0.49) and x >= 0:
		return x
	else :
		return randint(0,node_count-1)

def tlbo(G, N, itmax,  L, l):

	shortest_path_length = dict()
	particles =initialize_particles(G, N)
	latencies = calculate_latency(G, particles, shortest_path_length, L, l)
	node_count = nx.number_of_nodes(G)

	for itr in range(0, itmax):


		X_mean = calculate_particle_mean(particles, node_count)
		X_best, best_latency = find_x_best(particles, latencies)
		print 'tlbo -', itr, best_latency

		rt = get_random_dict(node_count)

		TF = 1 + random()
		new_particles = particles
		for i in range(0, N):

			for key, value in particles[i].items():
				new_particles[i][key] = value + rt[key] * (X_best[key] - TF * X_mean[key])
				new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

		new_latencies = calculate_latency(G, new_particles, shortest_path_length, L, l)

		for i in range(0, N):
			if new_latencies[i] < latencies[i]:
				latencies[i] = new_latencies[i]
				particles[i] = new_particles[i]


		rs = get_random_dict(node_count)
		for i in range(0, N):
			X_peer = randint(0, N-1)
			while N>1 and (i == X_peer):
				X_peer = randint(0, N-1)

			if latencies[i] < latencies[X_peer]:
				for key, value in particles[i].items():
					new_particles[i][key] = value + rs[key]*(value - particles[X_peer][key])
					new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)

			else :
				for key, value in particles[i].items():
					new_particles[i][key] = value + rs[key]*(particles[X_peer][key] - value)
					new_particles[i][key] = safe_check(key, new_particles[i][key], node_count)
			

		new_latencies = calculate_latency(G, new_particles, shortest_path_length, L, l)

		for i in range(0, N):
			if new_latencies[i] < latencies[i]:
				latencies[i] = new_latencies[i]
				particles[i] = new_particles[i]

	opt_placement, opt_latency = find_x_best(particles, latencies)

	return opt_placement, calculate_actual_avg_latency(G, opt_placement, shortest_path_length, L, l)


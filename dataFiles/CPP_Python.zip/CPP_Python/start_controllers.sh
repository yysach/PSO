image='onosproject/onos:1.11.1'

#Stopping and removing all existing containers
for i in `seq 1 15`;
	do
		docker stop onos$i
		docker rm onos$i
	done 

#Running required no. of controllers
for i in `seq 1 $1`
	do
		docker run -t -d --name onos$i $image
	done

#Running python script for activating apps
sleep 100
python activate_apps.py $1

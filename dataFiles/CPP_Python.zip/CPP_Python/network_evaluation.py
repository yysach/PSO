# Evaluate network performance


#Calculating Average ping time between any two hosts
def avgPingTime(net, nodes, load):
	try:
		tot = 0
		count = 0
		for outputs in net.pingFull(hosts=nodes, timeout=None):
			src, dest, ping_outputs = outputs
			sent, received, rttmin, rttavg, rttmax, rttdev = ping_outputs
			tot += rttavg
			count = count + 1
		return tot/count
	except Exception as e:
		print('avgPingTime::', e)
		return -1


#Calculating Average speed between any two hosts using iperf
def avgSpeedUsingPerf(net, nodes, G, load):
	try:
		tot = 0
		count = 0
		for i in G.nodes():
			for j in G.nodes():
				if i!=j:
					result = net.iperf(hosts=[nodes[i], nodes[j]], seconds=0.02, port=5001)
					tot += (float(result[0].split(' ')[0]) + float(result[1].split(' ')[0]))/2
					count = count + 1
		return tot/count
	except Exception as e:
		print('avgSpeedUsingIperf::', e)
		return -1
